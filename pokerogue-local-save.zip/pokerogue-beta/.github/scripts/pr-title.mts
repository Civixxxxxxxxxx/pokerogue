/*
 * SPDX-FileCopyrightText: 2024-2026 Pagefault Games
 * SPDX-FileContributor: NightKev <https://github.com/DayKev>
 * SPDX-FileContributor: OrangeRed <https://github.com/OrangeRed>
 *
 * SPDX-License-Identifier: AGPL-3.0-only
 */

import { getInput, info, setFailed } from "@actions/core";
import { context, getOctokit } from "@actions/github";

const PREFIXES = [
  "balance", // Primarily a balance change
  "chore", // Misc project upkeep (e.g. updating submodules, updating dependencies, reverting a bad commit) not covered by other prefixes
  "dev", // Improving the developer experience (such as by modifying lint rules or creating cli scripts)
  "docs", // Primarily adding/updating documentation
  "feat", // Adding a new feature (e.g. adding a new implementation of a move) or redesigning an existing feature
  "fix", // Fixing a bug
  "github", // Updating the CI pipeline or otherwise modifying something in the `./github/**` directory
  "i18n", // Adding/modifying translation keys, etc
  "misc", // A change that doesn't fit any other prefix
  "perf", // A refactor aimed at improving performance
  "refactor", // A change that doesn't impact functionality or fix any bugs (except incidentally)
  "revert", // Reverting a bad commit
  "test", // Primarily adding/updating tests or modifying the test framework
] as const;

type Prefixes = (typeof PREFIXES)[number];

const ALL_SCOPES = [
  "ability",
  "ai",
  "audio",
  "battle", // Relating to the general battle engine
  "biomes",
  "challenge",
  "encounter", // Mystery Encounters
  "event", // e.g. adding a Christmas event to the game
  "graphics", // Anything related to art/graphics (adding new sprites, fixing a sprite that isn't displaying properly, etc)
  "item",
  "move",
  "ui", // UI/UX
] as const;

type AllScopes = (typeof ALL_SCOPES)[number] | "beta";

const PREFIX_SCOPE_MAP: Readonly<Record<Prefixes, readonly AllScopes[]>> = {
  balance: ["ability", "ai", "biomes", "challenge", "encounter", "event", "item", "move"],
  chore: [],
  dev: [],
  docs: ALL_SCOPES,
  feat: ALL_SCOPES,
  // Add special scope for fixing bugs that only existed on the beta branch
  fix: [...ALL_SCOPES, "beta"],
  github: [],
  i18n: [],
  misc: [],
  perf: [],
  refactor: ALL_SCOPES,
  revert: [],
  test: ALL_SCOPES,
} as const;

async function run(): Promise<void> {
  try {
    const authToken = getInput("github_token", { required: true });

    const { eventName } = context;
    if (eventName !== "pull_request") {
      setFailed(`Invalid event: ${eventName}`);
      return;
    }
    if (!context.payload.pull_request) {
      setFailed("Error parsing pull request data!");
      return;
    }

    const client = getOctokit(authToken);
    // The pull request info on the context isn't up to date.
    // When the user updates the title and re-runs the workflow, it would be outdated.
    // Therefore fetch the pull request via the REST API to ensure we use the current title.
    const { data: pullRequest } = await client.rest.pulls.get({
      owner: context.payload.pull_request.base.user.login,
      repo: context.payload.pull_request.base.repo.name,
      pull_number: context.payload.pull_request.number,
    });

    const { title } = pullRequest;
    info(
      "Info on PR title formatting: https://github.com/pagefaultgames/pokerogue/blob/beta/CONTRIBUTING.md#-submitting-a-pull-request",
    );
    info(`Pull Request title: "${title}"`);

    // if (title.length > 72) {
    //   core.setFailed(`Max title length of 72 exceeded! Current length: ${title.length}`);
    //   return;
    // }

    // Note: `!` allowed before `:` for changes including a save migrator and/or version increase
    const terminology = `
Terminology: fix(move): Future Sight no longer crashes
             ^   ^      ^
             |   |      |__ Subject
             |   |_________ Scope (optional)
             |_____________ Prefix
`;

    info(terminology);

    // Example usage of regex: https://regex101.com/r/FeN8jG/9
    const regex = /^([a-z0-9]+)(\([a-z]+\))?!?: .+/;
    const regexResult = regex.exec(title);
    if (!regexResult) {
      setFailed(`Pull Request title "${title}" failed to match "Prefix(Scope): Subject" format!`);
      return;
    }

    const prefix = regexResult[1];
    const scope = regexResult[2]?.replace(/[()]/g, "") as AllScopes | undefined;

    if (!(PREFIXES as readonly string[]).includes(prefix)) {
      setFailed(`Pull Request title "${title}" did not match any of the prefixes: [${PREFIXES}]`);
      return;
    }

    // biome-ignore lint/style/useExplicitLengthCheck: doubles as a nullish check for `scope`
    if (scope?.length && !PREFIX_SCOPE_MAP[prefix as Prefixes].includes(scope)) {
      setFailed(`Pull Request title "${title}" has an invalid prefix (${prefix}) + scope (${scope}) combination!`);
      return;
    }
  } catch (error) {
    setFailed((error as Error).message);
  }
}

await run();
