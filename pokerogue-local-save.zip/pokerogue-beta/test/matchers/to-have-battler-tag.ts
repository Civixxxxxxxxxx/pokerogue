import { getPokemonNameWithAffix } from "#app/messages";
import { BattlerTag, type BattlerTagTypeMap } from "#data/battler-tags";
import { BattlerTagType } from "#enums/battler-tag-type";
import type { OneOther } from "#test/@types/test-helpers";
import { getEnumStr, getOnelineDiffStr } from "#test/utils/string-utils";
import { isPokemonInstance, receivedStr } from "#test/utils/test-utils";
import type { BattlerTagDataMap, SerializableBattlerTagType } from "#types/battler-tags";
import type { MatcherState, SyncExpectationResult } from "@vitest/expect";

/**
 * Helper type for a partially filled serializable {@linkcode BattlerTag}.
 * Allows for caching to avoid repeated instantiation and speed up typechecking.
 * @typeParam B - The {@linkcode BattlerTagType} being checked
 * @internal
 * @sealed
 */
type PartiallyFilledSerializableBattlerTag<B extends SerializableBattlerTagType> = //
  OneOther<BattlerTagDataMap[B], "tagType"> & { tagType: B };

/**
 * Helper type for a partially filled non-serializable battler tag.
 * Allows for caching to avoid repeated instantiation and speed up typechecking.
 * @typeParam B - The {@linkcode BattlerTagType} being checked
 * @internal
 * @sealed
 */
type PartiallyFilledNonSerializableBattlerTag<B extends BattlerTagType> = //
  OneOther<BattlerTagTypeMap[B], "tagType"> & { tagType: B };

/**
 * Parameter type for {@linkcode toHaveBattlerTag}, accepting a partially filled {@linkcode BattlerTag} of the given type.
 * @typeParam B - The {@linkcode BattlerTagType} being checked
 * @remarks
 * If `B` corresponds to a {@linkcode SerializableBattlerTagType | serializable BattlerTag}, only properties allowed to be serialized
 * (i.e. can change across instances) will be present and able to be checked.
 * @sealed
 */
export type PartiallyFilledBattlerTag<B extends BattlerTagType> = [B] extends [SerializableBattlerTagType]
  ? PartiallyFilledSerializableBattlerTag<B>
  : PartiallyFilledNonSerializableBattlerTag<B>;

/**
 * Matcher that checks if a {@linkcode Pokemon} has a specific {@linkcode BattlerTag}.
 * @param received - The object to check. Should be a {@linkcode Pokemon}
 * @param expectedTag - The `BattlerTagType` of the desired tag, an existing `BattlerTag` to verify ownership of,
 * or a partially filled object containing the desired properties
 * @returns Whether the matcher passed
 */
export function toHaveBattlerTag<B extends BattlerTagType>(
  this: Readonly<MatcherState>,
  received: unknown,
  expectedTag: B | BattlerTagTypeMap[B] | PartiallyFilledBattlerTag<B>,
): SyncExpectationResult {
  if (!isPokemonInstance(received)) {
    return {
      pass: this.isNot,
      message: () => `Expected to receive a Pokémon, but got ${receivedStr(received)}!`,
    };
  }

  const pkmName = getPokemonNameWithAffix(received);

  // Coerce lone `tagType`s into objects
  const eTag = typeof expectedTag === "object" ? expectedTag : { tagType: expectedTag };
  const gotTag = received.getTag(eTag.tagType as B);

  // If checking exclusively tag type OR no tags were found, break out early.
  if (typeof expectedTag !== "object" || !gotTag) {
    const pass = !!gotTag;
    // "BattlerTagType.SEEDED (=1)"
    const expectedTagStr = getEnumStr(BattlerTagType, eTag.tagType, { prefix: "BattlerTagType." });

    return {
      pass,
      message: () =>
        pass
          ? `Expected ${pkmName} to NOT have a tag of type ${expectedTagStr}, but it did!`
          : `Expected ${pkmName} to have a tag of type ${expectedTagStr}, but it didn't!`,
      expected: expectedTag,
      actual: received.summonData.tags.map(t => t.tagType),
    };
  }

  // Check for equality with the provided tag
  const pass =
    eTag instanceof BattlerTag
      ? gotTag === eTag
      : this.equals(gotTag, eTag, [...this.customTesters, this.utils.subsetEquality, this.utils.iterableEquality]);

  const expectedStr = getOnelineDiffStr.call(this, expectedTag);
  return {
    pass,
    message: () =>
      pass
        ? `Expected ${pkmName} to NOT have a tag matching ${expectedStr}, but it did!`
        : `Expected ${pkmName} to have a tag matching ${expectedStr}, but it didn't!`,
    expected: expectedTag,
    actual: gotTag,
  };
}
