import { SESSION_ID_COOKIE_NAME } from "#app/constants";
import { initializeGame } from "#init/init";
import { manageListeners } from "#test/framework/listeners-manager";
import { MockConsole } from "#test/mocks/mock-console/mock-console";
import { mockContext } from "#test/mocks/mock-context-canvas";
import { mockLocalStorage } from "#test/mocks/mock-local-storage";
import { MockImage } from "#test/mocks/mocks-container/mock-image";
import { blobToString } from "#test/utils/game-manager-utils";
import { setCookie } from "#utils/cookies";
import Phaser from "phaser";
import BBCodeText from "phaser3-rex-plugins/plugins/bbcodetext";
import InputText from "phaser3-rex-plugins/plugins/inputtext";

let wasInitialized = false;

/** Run initialization code upon starting a new file, both per-suite and per-instance ones. */
export async function initTests(): Promise<void> {
  setupStubs();
  if (!wasInitialized) {
    await initializeGame();
    wasInitialized = true;
    // this needs to be done after `audioManager` is assigned to in `initializeGame()`
    // TODO: modify data export script so `initGlobalAudioManager()` is no longer necessary?
    const { audioManager } = await import("#app/global-audio-manager");
    audioManager.playBgm = () => null;
    audioManager.replaceBgmUntilEnd = () => null!;
  }

  manageListeners();
}

/** Setup various stubs for testing. */
// TODO: Move this into a dedicated stub file instead of running it once per test instance
// TODO: review these to see which are actually necessary
// TODO: Investigate why this resets on new test suite start
function setupStubs(): void {
  // TODO: Make this type safe
  Object.defineProperties(globalThis, {
    localStorage: {
      value: mockLocalStorage(),
    },
    console: {
      value: new MockConsole(),
    },
    matchMedia: {
      value: () => ({
        matches: false,
      }),
    },
  });
  Object.defineProperty(document, "fonts", {
    writable: true,
    value: {
      add: () => {},
    },
  });

  BBCodeText.prototype.destroy = () => null;
  BBCodeText.prototype.resize = () => null as any;
  InputText.prototype.setElement = () => null as any;
  InputText.prototype.resize = () => null as any;
  Phaser.GameObjects.Image = MockImage as any;
  window.URL.createObjectURL = (blob: Blob) => {
    blobToString(blob).then((data: string) => {
      localStorage.setItem("toExport", data);
    });
    return null as any;
  };
  navigator.getGamepads = () => [];
  setCookie(SESSION_ID_COOKIE_NAME, "fake_token");
  HTMLCanvasElement.prototype.getContext = () => mockContext;
}

/**
 * Closes the current mock server and initializes a new mock server.
 * @remarks
 * This is run at the beginning of every API test file.
 */
export async function initServerForApiTests() {
  global.server?.close();
  const { setupServer } = await import("msw/node");
  global.server = setupServer();
  global.server.listen({ onUnhandledRequest: "error" });
  return global.server;
}
