import { AbilityId } from "#enums/ability-id";
import { BattlerIndex } from "#enums/battler-index";
import { BattlerTagType } from "#enums/battler-tag-type";
import { MoveId } from "#enums/move-id";
import { MoveResult } from "#enums/move-result";
import { PokemonAnimType } from "#enums/pokemon-anim-type";
import { SpeciesId } from "#enums/species-id";
import { EFFECTIVE_STATS } from "#enums/stat";
import { StatusEffect } from "#enums/status-effect";
import { WeatherType } from "#enums/weather-type";
import { GameManager } from "#test/framework/game-manager";
import Phaser from "phaser";
import { beforeAll, beforeEach, describe, expect, it, vi } from "vitest";

describe("Abilities - Commander", () => {
  let phaserGame: Phaser.Game;
  let game: GameManager;

  beforeAll(() => {
    phaserGame = new Phaser.Game({
      type: Phaser.HEADLESS,
    });
  });

  beforeEach(() => {
    game = new GameManager(phaserGame);
    game.override
      .startingLevel(100)
      .enemyLevel(100)
      .moveset([MoveId.LIQUIDATION, MoveId.MEMENTO, MoveId.SPLASH, MoveId.FLIP_TURN])
      .ability(AbilityId.COMMANDER)
      .battleStyle("double")
      .criticalHits(false)
      .enemySpecies(SpeciesId.SNORLAX)
      .enemyAbility(AbilityId.BALL_FETCH)
      .enemyMoveset(MoveId.TACKLE);

    vi.spyOn(game.scene, "triggerPokemonBattleAnim").mockReturnValue(true);
  });

  it("causes the source to jump into Dondozo's mouth, granting a stat boost and hiding the source", async () => {
    await game.classicMode.startBattle(SpeciesId.TATSUGIRI, SpeciesId.DONDOZO);

    const [tatsugiri, dondozo] = game.scene.getPlayerField();

    expect(game.scene.triggerPokemonBattleAnim).toHaveBeenLastCalledWith(tatsugiri, PokemonAnimType.COMMANDER_APPLY);
    expect(dondozo).toHaveBattlerTag(BattlerTagType.COMMANDED);
    EFFECTIVE_STATS.forEach(stat => {
      expect(dondozo).toHaveStatStage(stat, 2);
    });

    game.move.use(MoveId.SPLASH, BattlerIndex.PLAYER_2);
    expect(game.scene.currentBattle.turnCommands[0]?.skip).toBeTruthy();

    // Force both enemies to target the Tatsugiri
    await game.move.forceEnemyMove(MoveId.TACKLE, BattlerIndex.PLAYER);
    await game.move.forceEnemyMove(MoveId.TACKLE, BattlerIndex.PLAYER);

    await game.toEndOfTurn();
    const [enemy1, enemy2] = game.scene.getEnemyField();
    expect(enemy1).toHaveUsedMove({ move: MoveId.TACKLE, result: MoveResult.MISS });
    expect(enemy2).toHaveUsedMove({ move: MoveId.TACKLE, result: MoveResult.MISS });
    expect(tatsugiri).toHaveFullHp();
  });

  it("should activate when a Dondozo switches in and cancel the source's move", async () => {
    game.override.enemyMoveset(MoveId.SPLASH);

    await game.classicMode.startBattle(SpeciesId.TATSUGIRI, SpeciesId.MAGIKARP, SpeciesId.DONDOZO);

    const [tatsugiri, _, dondozo] = game.scene.getPlayerParty();

    game.move.select(MoveId.LIQUIDATION, 0, BattlerIndex.ENEMY);
    game.doSwitchPokemon(2);

    await game.phaseInterceptor.to("MovePhase", false);
    expect(game.scene.triggerPokemonBattleAnim).toHaveBeenCalledWith(tatsugiri, PokemonAnimType.COMMANDER_APPLY);

    expect(dondozo.getTag(BattlerTagType.COMMANDED)).toBeDefined();

    await game.phaseInterceptor.to("BerryPhase", false);
    expect(tatsugiri.getMoveHistory()).toHaveLength(0);
    expect(game.field.getEnemyPokemon()).toHaveFullHp();
  });

  it("source should reenter the field when Dondozo faints", async () => {
    await game.classicMode.startBattle(SpeciesId.TATSUGIRI, SpeciesId.DONDOZO);

    const [tatsugiri, dondozo] = game.scene.getPlayerField();

    expect(game.scene.triggerPokemonBattleAnim).toHaveBeenLastCalledWith(tatsugiri, PokemonAnimType.COMMANDER_APPLY);
    expect(dondozo.getTag(BattlerTagType.COMMANDED)).toBeDefined();

    game.move.select(MoveId.MEMENTO, 1, BattlerIndex.ENEMY);

    expect(game.scene.currentBattle.turnCommands[0]?.skip).toBeTruthy();

    await game.move.selectEnemyMove(MoveId.TACKLE, BattlerIndex.PLAYER);
    await game.move.selectEnemyMove(MoveId.TACKLE, BattlerIndex.PLAYER);

    game.setTurnOrder([BattlerIndex.PLAYER_2, BattlerIndex.ENEMY, BattlerIndex.ENEMY_2, BattlerIndex.PLAYER]);

    await game.phaseInterceptor.to("FaintPhase", false);
    expect(dondozo.getTag(BattlerTagType.COMMANDED)).toBeUndefined();
    expect(game.scene.triggerPokemonBattleAnim).toHaveBeenLastCalledWith(dondozo, PokemonAnimType.COMMANDER_REMOVE);

    await game.phaseInterceptor.to("BerryPhase", false);
    expect(tatsugiri.isFullHp()).toBeFalsy();
  });

  it("source should still take damage from Poison while hidden", async () => {
    game.override.statusEffect(StatusEffect.POISON).enemyMoveset(MoveId.SPLASH);

    await game.classicMode.startBattle(SpeciesId.TATSUGIRI, SpeciesId.DONDOZO);

    const [tatsugiri, dondozo] = game.scene.getPlayerField();

    expect(game.scene.triggerPokemonBattleAnim).toHaveBeenLastCalledWith(tatsugiri, PokemonAnimType.COMMANDER_APPLY);
    expect(dondozo.getTag(BattlerTagType.COMMANDED)).toBeDefined();

    game.move.select(MoveId.SPLASH, 1);

    expect(game.scene.currentBattle.turnCommands[0]?.skip).toBeTruthy();

    await game.phaseInterceptor.to("TurnEndPhase");
    expect(tatsugiri.isFullHp()).toBeFalsy();
  });

  it("source should still take damage from Salt Cure while hidden", async () => {
    game.override.enemyMoveset(MoveId.SPLASH);

    await game.classicMode.startBattle(SpeciesId.TATSUGIRI, SpeciesId.DONDOZO);

    const [tatsugiri, dondozo] = game.scene.getPlayerField();

    expect(game.scene.triggerPokemonBattleAnim).toHaveBeenLastCalledWith(tatsugiri, PokemonAnimType.COMMANDER_APPLY);
    expect(dondozo.getTag(BattlerTagType.COMMANDED)).toBeDefined();

    tatsugiri.addTag(BattlerTagType.SALT_CURED, 0, MoveId.NONE, game.scene.getField()[BattlerIndex.ENEMY].id);

    game.move.select(MoveId.SPLASH, 1);

    expect(game.scene.currentBattle.turnCommands[0]?.skip).toBeTruthy();

    await game.phaseInterceptor.to("TurnEndPhase");
    expect(tatsugiri.isFullHp()).toBeFalsy();
  });

  it("source should still take damage from Sandstorm while hidden", async () => {
    game.override.weather(WeatherType.SANDSTORM).enemyMoveset(MoveId.SPLASH);

    await game.classicMode.startBattle(SpeciesId.TATSUGIRI, SpeciesId.DONDOZO);

    const [tatsugiri, dondozo] = game.scene.getPlayerField();

    expect(game.scene.triggerPokemonBattleAnim).toHaveBeenLastCalledWith(tatsugiri, PokemonAnimType.COMMANDER_APPLY);
    expect(dondozo.getTag(BattlerTagType.COMMANDED)).toBeDefined();

    game.move.select(MoveId.SPLASH, 1);

    expect(game.scene.currentBattle.turnCommands[0]?.skip).toBeTruthy();

    await game.phaseInterceptor.to("TurnEndPhase");
    expect(tatsugiri.isFullHp()).toBeFalsy();
  });

  it("should make Dondozo immune to being forced out", async () => {
    game.override.enemyMoveset([MoveId.SPLASH, MoveId.WHIRLWIND]);

    await game.classicMode.startBattle(SpeciesId.TATSUGIRI, SpeciesId.DONDOZO);

    const [tatsugiri, dondozo] = game.scene.getPlayerField();

    expect(game.scene.triggerPokemonBattleAnim).toHaveBeenLastCalledWith(tatsugiri, PokemonAnimType.COMMANDER_APPLY);
    expect(dondozo.getTag(BattlerTagType.COMMANDED)).toBeDefined();

    game.move.select(MoveId.SPLASH, 1);

    expect(game.scene.currentBattle.turnCommands[0]?.skip).toBeTruthy();

    await game.move.selectEnemyMove(MoveId.WHIRLWIND, BattlerIndex.PLAYER_2);
    await game.move.selectEnemyMove(MoveId.SPLASH);

    // Test may time out here if Whirlwind forced out a Pokemon
    await game.phaseInterceptor.to("TurnEndPhase");
    expect(dondozo.isActive(true)).toBeTruthy();
  });

  it("should interrupt the source's semi-invulnerability", async () => {
    await game.classicMode.startBattle(SpeciesId.TATSUGIRI, SpeciesId.MAGIKARP, SpeciesId.DONDOZO);

    const [tatsugiri, , dondozo] = game.scene.getPlayerParty();

    game.move.use(MoveId.DIVE, BattlerIndex.PLAYER, BattlerIndex.ENEMY);
    game.move.use(MoveId.SPLASH, BattlerIndex.PLAYER_2);
    await game.move.forceEnemyMove(MoveId.SPLASH);
    await game.move.forceEnemyMove(MoveId.SPLASH);
    await game.toNextTurn();

    expect(tatsugiri).toHaveBattlerTag(BattlerTagType.UNDERWATER);

    game.doSwitchPokemon(2);
    await game.phaseInterceptor.to("MovePhase", false);

    expect(tatsugiri).not.toHaveBattlerTag(BattlerTagType.UNDERWATER);
    expect(dondozo).toHaveBattlerTag(BattlerTagType.COMMANDED);

    await game.toEndOfTurn();

    expect(game.field.getEnemyPokemon()).toHaveFullHp();
  });

  describe("Self-Switching and Escape Items", () => {
    beforeEach(() => {
      game.override.enemyMoveset([MoveId.SPLASH]);
    });

    it("should allow Dondozo to deal damage with U-turn but prevent it from switching out", async () => {
      await game.classicMode.startBattle(SpeciesId.DONDOZO, SpeciesId.TATSUGIRI, SpeciesId.PIDGEY);

      const [dondozo] = game.scene.getPlayerField();
      game.move.use(MoveId.U_TURN);
      await game.toNextTurn();

      expect(dondozo.isOnField()).toBe(true);
      expect(dondozo).toHaveUsedMove({ move: MoveId.U_TURN, result: MoveResult.SUCCESS });
      expect(game.scene.getPlayerField()[0].species.speciesId).toBe(SpeciesId.DONDOZO);
    });

    it("should fail the switch when Dondozo uses Baton Pass", async () => {
      await game.classicMode.startBattle(SpeciesId.DONDOZO, SpeciesId.TATSUGIRI, SpeciesId.PIDGEY);

      const [dondozo] = game.scene.getPlayerField();
      game.move.use(MoveId.BATON_PASS);
      await game.toNextTurn();

      expect(dondozo.isOnField()).toBe(true);
      expect(dondozo).toHaveUsedMove({ move: MoveId.BATON_PASS, result: MoveResult.FAIL });
      expect(game.scene.getPlayerField()[0].species.speciesId).toBe(SpeciesId.DONDOZO);
    });
  });
});
