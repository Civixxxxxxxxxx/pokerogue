import { AbilityId } from "#enums/ability-id";
import { ArenaTagSide } from "#enums/arena-tag-side";
import { ArenaTagType } from "#enums/arena-tag-type";
import { MoveId } from "#enums/move-id";
import { SpeciesId } from "#enums/species-id";
import { Stat } from "#enums/stat";
import { WeatherType } from "#enums/weather-type";
import { GameManager } from "#test/framework/game-manager";
import Phaser from "phaser";
import { beforeAll, beforeEach, describe, expect, it } from "vitest";

describe("Move - Trick Room", () => {
  let phaserGame: Phaser.Game;
  let game: GameManager;

  beforeAll(() => {
    phaserGame = new Phaser.Game({
      type: Phaser.HEADLESS,
    });
  });

  beforeEach(() => {
    game = new GameManager(phaserGame);
    game.override
      .ability(AbilityId.BALL_FETCH)
      .battleStyle("single")
      .criticalHits(false)
      .enemySpecies(SpeciesId.MAGIKARP)
      .enemyAbility(AbilityId.BALL_FETCH)
      .enemyMoveset(MoveId.SPLASH);
  });

  it("should reverse the speed order of combatants while active", async () => {
    await game.classicMode.startBattle(SpeciesId.FEEBAS);

    const feebas = game.field.getPlayerPokemon();
    const karp = game.field.getEnemyPokemon();
    feebas.setStat(Stat.SPD, 2);
    karp.setStat(Stat.SPD, 1);
    expect(game.field.getSpeedOrder()).toEqual([feebas, karp]);

    // Add trick room to the field
    game.move.use(MoveId.TRICK_ROOM);
    await game.toNextTurn();

    expect(game).toHaveArenaTag({
      tagType: ArenaTagType.TRICK_ROOM,
      side: ArenaTagSide.BOTH,
      sourceId: feebas.id,
      sourceMove: MoveId.TRICK_ROOM,
      turnCount: 4, // The 5 turn limit _includes_ the current turn!
    });
    expect(game.field.getSpeedOrder(false, false)).toEqual([karp, feebas]);

    game.move.use(MoveId.SUNNY_DAY);
    await game.move.forceEnemyMove(MoveId.RAIN_DANCE);
    await game.toEndOfTurn();

    expect(game).toHaveWeather(WeatherType.SUNNY);
  });

  it("should be removed when overlapped", async () => {
    await game.classicMode.startBattle(SpeciesId.FEEBAS);

    const feebas = game.field.getPlayerPokemon();

    // Add trick room to the field, then add it again!
    game.scene.arena.addTag(ArenaTagType.TRICK_ROOM, 5, MoveId.TRICK_ROOM, feebas.id);

    expect(game).toHaveArenaTag(ArenaTagType.TRICK_ROOM);

    game.scene.arena.addTag(ArenaTagType.TRICK_ROOM, 5, MoveId.TRICK_ROOM, feebas.id);

    expect(game).not.toHaveArenaTag(ArenaTagType.TRICK_ROOM);
  });
});
