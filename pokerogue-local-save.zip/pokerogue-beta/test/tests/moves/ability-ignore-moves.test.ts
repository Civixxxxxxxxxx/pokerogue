import { AbilityId } from "#enums/ability-id";
import { BattlerIndex } from "#enums/battler-index";
import { MoveId } from "#enums/move-id";
import { SpeciesId } from "#enums/species-id";
import { GameManager } from "#test/framework/game-manager";
import Phaser from "phaser";
import { beforeAll, beforeEach, describe, expect, it } from "vitest";

describe("Moves - Ability-Ignoring Moves", () => {
  let phaserGame: Phaser.Game;
  let game: GameManager;

  beforeAll(() => {
    phaserGame = new Phaser.Game({
      type: Phaser.HEADLESS,
    });
  });

  beforeEach(() => {
    game = new GameManager(phaserGame);
    game.override
      .ability(AbilityId.BALL_FETCH)
      .startingLevel(200)
      .battleStyle("single")
      .criticalHits(false)
      .enemySpecies(SpeciesId.MAGIKARP)
      .enemyAbility(AbilityId.STURDY)
      .enemyMoveset(MoveId.SPLASH);
  });

  it.each<{ name: string; move: MoveId }>([
    { name: "Sunsteel Strike", move: MoveId.SUNSTEEL_STRIKE },
    { name: "Moongeist Beam", move: MoveId.MOONGEIST_BEAM },
    { name: "Photon Geyser", move: MoveId.PHOTON_GEYSER },
  ])("$name should ignore all other Pokemon's ignorable abilities during move use", async ({ move }) => {
    game.override.battleStyle("double");
    await game.classicMode.startBattle(SpeciesId.FEEBAS);

    const feebas = game.field.getPlayerPokemon();
    const [karp1, karp2] = game.scene.getEnemyField();
    game.field.mockAbility(karp2, AbilityId.FRIEND_GUARD);

    game.move.use(move, BattlerIndex.PLAYER, BattlerIndex.ENEMY);
    await game.phaseInterceptor.to("MoveEffectPhase");

    expect(game.scene.arena.ignoreAbilities).toBe(true);
    expect(game.scene.arena.ignoringEffectSource).toBe(feebas.getBattlerIndex());

    await game.toEndOfTurn();

    // should bypass sturdy OKHO prevention
    expect(game.scene.arena.ignoreAbilities).toBe(false);
    expect(karp1).not.toHaveAbilityApplied(AbilityId.STURDY);
    expect(karp2).not.toHaveAbilityApplied(AbilityId.FRIEND_GUARD);
    expect(karp1).toHaveFainted();
  });

  // TODO: Move test from flower gift's file over here
  it.todo("should ignore the abilities of the user's allies");

  it("should not ignore abilities when called by move-calling moves", async () => {
    await game.classicMode.startBattle(SpeciesId.FEEBAS);

    const feebas = game.field.getPlayerPokemon();
    const karp = game.field.getEnemyPokemon();

    game.move.use(MoveId.METRONOME);
    game.move.forceMetronomeMove(MoveId.PHOTON_GEYSER, true);
    // TODO: This has to change to `MoveEffectPhase` once move-calling moves are refactored
    // to not create a new `MovePhase`
    await game.phaseInterceptor.to("MoveEndPhase");
    await game.phaseInterceptor.to("MoveEndPhase", false);

    expect(feebas).toHaveUsedMove(MoveId.PHOTON_GEYSER);
    expect(game.scene.arena.ignoreAbilities).toBe(false);

    await game.toEndOfTurn();

    expect(karp).toHaveAbilityApplied(AbilityId.STURDY);
    expect(karp).not.toHaveFainted();
  });

  // TODO: Verify this behavior on cart
  it("should ignore enemy abilities when called by Instruct", async () => {
    game.override.battleStyle("double");
    await game.classicMode.startBattle(SpeciesId.SOLGALEO, SpeciesId.LUNALA);

    const solgaleo = game.field.getPlayerPokemon();

    game.move.use(MoveId.SUNSTEEL_STRIKE, BattlerIndex.PLAYER, BattlerIndex.ENEMY);
    game.move.use(MoveId.INSTRUCT, BattlerIndex.PLAYER_2, BattlerIndex.PLAYER);
    game.setTurnOrder([BattlerIndex.PLAYER, BattlerIndex.PLAYER_2, BattlerIndex.ENEMY, BattlerIndex.ENEMY_2]);

    await game.phaseInterceptor.to("MoveEffectPhase"); // initial attack
    await game.phaseInterceptor.to("MoveEffectPhase"); // instruct
    await game.phaseInterceptor.to("MoveEffectPhase"); // instructed move use

    expect(game.scene.arena.ignoreAbilities).toBe(true);
    expect(game.scene.arena.ignoringEffectSource).toBe(solgaleo.getBattlerIndex());

    await game.toEndOfTurn();

    // Both the initial and redirected instruct use ignored sturdy
    const [enemy1, enemy2] = game.scene.getEnemyField();
    expect(enemy1).not.toHaveAbilityApplied(AbilityId.STURDY);
    expect(enemy2).not.toHaveAbilityApplied(AbilityId.STURDY);
    expect(enemy1).toHaveFainted();
    expect(enemy2).toHaveFainted();
  });
});
