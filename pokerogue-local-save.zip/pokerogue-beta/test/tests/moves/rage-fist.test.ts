import { allMoves } from "#data/data-lists";
import { AbilityId } from "#enums/ability-id";
import { BattlerIndex } from "#enums/battler-index";
import { MoveId } from "#enums/move-id";
import { SpeciesId } from "#enums/species-id";
import type { Move } from "#moves/move";
import { GameManager } from "#test/framework/game-manager";
import Phaser from "phaser";
import { beforeAll, beforeEach, describe, expect, it, vi } from "vitest";

describe("Moves - Rage Fist", () => {
  let phaserGame: Phaser.Game;
  let game: GameManager;
  let move: Move;

  beforeAll(() => {
    phaserGame = new Phaser.Game({
      type: Phaser.HEADLESS,
    });
  });

  beforeEach(() => {
    move = allMoves[MoveId.RAGE_FIST];
    game = new GameManager(phaserGame);
    game.override
      .battleStyle("single")
      .moveset([MoveId.RAGE_FIST, MoveId.SPLASH, MoveId.SUBSTITUTE, MoveId.TIDY_UP])
      .startingLevel(100)
      .enemyLevel(1)
      .enemySpecies(SpeciesId.MAGIKARP)
      .enemyAbility(AbilityId.BALL_FETCH)
      .enemyMoveset(MoveId.DOUBLE_KICK);

    vi.spyOn(move, "calculateBattlePower");
  });

  it("should gain power per hit taken", async () => {
    await game.classicMode.startBattle(SpeciesId.FEEBAS);

    game.move.select(MoveId.RAGE_FIST);
    game.setTurnOrder([BattlerIndex.ENEMY, BattlerIndex.PLAYER]);
    await game.phaseInterceptor.to("TurnEndPhase");

    expect(move.calculateBattlePower).toHaveLastReturnedWith(150);
  });

  it("caps at 6 hits taken", async () => {
    await game.classicMode.startBattle(SpeciesId.FEEBAS);

    // spam splash against magikarp hitting us 2 times per turn
    game.move.select(MoveId.SPLASH);
    await game.toNextTurn();
    game.move.select(MoveId.SPLASH);
    await game.toNextTurn();
    game.move.select(MoveId.SPLASH);
    await game.toNextTurn();

    game.move.select(MoveId.RAGE_FIST);
    game.setTurnOrder([BattlerIndex.ENEMY, BattlerIndex.PLAYER]);
    await game.phaseInterceptor.to("TurnEndPhase");

    // hit 8 times, but nothing else
    expect(game.field.getPlayerPokemon().summonData.hitCount).toBe(8);
    expect(move.calculateBattlePower).toHaveLastReturnedWith(350);
  });

  it("should not count substitute hits or confusion damage", async () => {
    game.override.enemySpecies(SpeciesId.SHUCKLE).enemyMoveset([MoveId.CONFUSE_RAY, MoveId.DOUBLE_KICK]);

    await game.classicMode.startBattle(SpeciesId.REGIROCK);

    game.move.select(MoveId.SUBSTITUTE);
    await game.move.selectEnemyMove(MoveId.DOUBLE_KICK);
    game.setTurnOrder([BattlerIndex.PLAYER, BattlerIndex.ENEMY]);
    await game.toNextTurn();

    // no increase due to substitute
    expect(game.field.getPlayerPokemon().summonData.hitCount).toBe(0);

    // remove substitute and get confused
    game.move.select(MoveId.TIDY_UP);
    await game.move.selectEnemyMove(MoveId.CONFUSE_RAY);
    await game.toNextTurn();

    game.move.select(MoveId.RAGE_FIST);
    await game.move.selectEnemyMove(MoveId.CONFUSE_RAY);
    await game.move.forceConfusionActivation(true);
    await game.toNextTurn();

    // didn't go up from hitting ourself
    expect(game.field.getPlayerPokemon().summonData.hitCount).toBe(0);
  });
});
